const mongoose = require('mongoose');

const clubRequestSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    headOfClub: { type: String, required: true },
    email: { type: String, required: true },
    phone: { type: String, required: true },
    otherCommunication: { type: String },
    clubName: { type: String, required: true },
    goal: { type: String, required: true },
    description: { type: String },
    financing: { type: String },
    resourcesNeeded: { type: String },
    attractionMethods: { type: String },
    comment: { type: String },
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
}, {
    timestamps: true
});

module.exports = mongoose.model('ClubRequest', clubRequestSchema);