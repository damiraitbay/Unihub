const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const authMiddleware = require('../middlewares/authMiddleware'); // Проверка токена

// Регистрация пользователя
router.post('/register', userController.registerUser);

// Логин пользователя
router.post('/login', userController.loginUser);

// Получить информацию о пользователе
router.get('/:id', authMiddleware.verifyToken, userController.getUserInfo);

// Обновить информацию о пользователе
router.put('/:id', authMiddleware.verifyToken, userController.updateUserInfo);

// Удалить пользователя
router.delete('/:id', authMiddleware.verifyToken, userController.deleteUser);

module.exports = router;