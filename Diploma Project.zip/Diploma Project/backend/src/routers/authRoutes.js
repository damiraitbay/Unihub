const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController'); // Импортируем контроллер

// Маршрут для регистрации
router.post('/register', authController.register);

// Маршрут для подтверждения регистрации
router.post('/verify', authController.verify);

// Маршрут для логина
router.post('/login', authController.loginUser);

// Маршрут для запроса на сброс пароля
router.post('/forgot-password', authController.forgotPassword);

// Маршрут для сброса пароля
router.post('/reset-password', authController.resetPassword);

module.exports = router;