const express = require('express');
const router = express.Router();

// ✅ Деструктурированный импорт функций из контроллера
const {
    createClubRequest,
    getAllClubRequests,
    updateClubRequestStatus,
    approveAndCreateClub
} = require('../controllers/clubRequestController');
const { authenticateUser, isAdmin } = require('../middlewares/authMiddleware');

// Пользователь отправляет заявку
router.post('/request', authenticateUser, createClubRequest);

// Админ получает все заявки
router.get('/requests', authenticateUser, isAdmin, getAllClubRequests);

// Обновить статус вручную
router.put('/request/:id/status', authenticateUser, isAdmin, updateClubRequestStatus);

// Одобрить заявку и создать клуб
router.post('/request/:id/approve', authenticateUser, isAdmin, approveAndCreateClub);

module.exports = router;