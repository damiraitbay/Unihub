const express = require('express');
const router = express.Router();
const ticketController = require('../controllers/ticketController');

// POST /api/tickets
router.post('/', ticketController.createTicket);

// GET /api/tickets
router.get('/', ticketController.getAllTickets);

// GET /api/tickets/:id
router.get('/:id', ticketController.getTicketById);

// DELETE /api/tickets/:id
router.delete('/:id', ticketController.deleteTicket);

module.exports = router;