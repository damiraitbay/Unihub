const ClubRequest = require('../models/ClubRequest');
const Club = require('../models/Club');

const createClubRequest = async(req, res) => {
    try {
        const {
            headOfClub,
            email,
            phone,
            otherCommunication,
            clubName,
            goal,
            description,
            financing,
            resourcesNeeded,
            attractionMethods,
            comment,
        } = req.body;

        const newRequest = new ClubRequest({
            user: req.user._id,
            headOfClub,
            email,
            phone,
            otherCommunication,
            clubName,
            goal,
            description,
            financing,
            resourcesNeeded,
            attractionMethods,
            comment,
        });

        await newRequest.save();
        res.status(201).json({ message: 'Заявка отправлена успешно.', request: newRequest });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при создании заявки.', error });
    }
};

const getAllClubRequests = async(req, res) => {
    try {
        const requests = await ClubRequest.find().populate('user', 'name email role').sort({ createdAt: -1 });
        res.json({ requests });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при получении заявок.', error });
    }
};

const updateClubRequestStatus = async(req, res) => {
    try {
        const { status } = req.body;
        const request = await ClubRequest.findByIdAndUpdate(req.params.id, { status }, { new: true });

        if (!request) return res.status(404).json({ message: 'Заявка не найдена.' });

        res.json({ message: `Статус обновлён на ${status}.`, request });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при обновлении.', error });
    }
};

const approveAndCreateClub = async(req, res) => {
    try {
        const request = await ClubRequest.findById(req.params.id);
        if (!request) return res.status(404).json({ message: 'Заявка не найдена.' });

        if (request.status === 'approved') {
            return res.status(400).json({ message: 'Заявка уже одобрена.' });
        }

        const newClub = new Club({
            name: request.clubName,
            description: request.description,
            adminId: request.user,
        });

        await newClub.save();

        request.status = 'approved';
        await request.save();
        res.status(201).json({ message: 'Клуб создан на основе заявки.', club: newClub });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при создании клуба.', error });
    }
};

module.exports = {
    createClubRequest,
    getAllClubRequests,
    updateClubRequestStatus,
    approveAndCreateClub,
};