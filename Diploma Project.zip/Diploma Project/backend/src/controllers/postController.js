const Post = require('../models/Post');

// 📥 Создать новый пост
exports.createPost = async(req, res) => {
    try {
        const post = await Post.create(req.body);
        res.status(201).json({ message: 'Пост создан', post });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при создании поста', error });
    }
};

// 📃 Получить все посты
exports.getAllPosts = async(req, res) => {
    try {
        const posts = await Post.find().populate('clubId');
        res.status(200).json(posts);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при получении постов', error });
    }
};

// 🔍 Получить пост по ID
exports.getPostById = async(req, res) => {
    try {
        const post = await Post.findById(req.params.id).populate('clubId');
        if (!post) return res.status(404).json({ message: 'Пост не найден' });
        res.status(200).json(post);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при получении поста', error });
    }
};

// ✏️ Обновить пост
exports.updatePost = async(req, res) => {
    try {
        const updated = await Post.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updated) return res.status(404).json({ message: 'Пост не найден' });
        res.status(200).json({ message: 'Пост обновлен', updated });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при обновлении поста', error });
    }
};

// ❌ Удалить пост
exports.deletePost = async(req, res) => {
    try {
        const deleted = await Post.findByIdAndDelete(req.params.id);
        if (!deleted) return res.status(404).json({ message: 'Пост не найден' });
        res.status(200).json({ message: 'Пост удален' });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при удалении поста', error });
    }
};