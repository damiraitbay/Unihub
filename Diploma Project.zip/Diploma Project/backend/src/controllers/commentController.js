const Comment = require('../models/Comment');

// 📥 Создать комментарий
exports.createComment = async(req, res) => {
    try {
        const comment = await Comment.create(req.body);
        res.status(201).json({ message: 'Комментарий создан', comment });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при создании комментария', error });
    }
};

// 📃 Получить все комментарии
exports.getAllComments = async(req, res) => {
    try {
        const comments = await Comment.find().populate('userId postId');
        res.status(200).json(comments);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при получении комментариев', error });
    }
};

// 🔍 Получить комментарий по ID
exports.getCommentById = async(req, res) => {
    try {
        const comment = await Comment.findById(req.params.id).populate('userId postId');
        if (!comment) return res.status(404).json({ message: 'Комментарий не найден' });
        res.status(200).json(comment);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при получении комментария', error });
    }
};

// ✏️ Обновить комментарий
exports.updateComment = async(req, res) => {
    try {
        const updated = await Comment.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updated) return res.status(404).json({ message: 'Комментарий не найден' });
        res.status(200).json({ message: 'Комментарий обновлен', updated });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при обновлении комментария', error });
    }
};

// ❌ Удалить комментарий
exports.deleteComment = async(req, res) => {
    try {
        const deleted = await Comment.findByIdAndDelete(req.params.id);
        if (!deleted) return res.status(404).json({ message: 'Комментарий не найден' });
        res.status(200).json({ message: 'Комментарий удален' });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при удалении комментария', error });
    }
};