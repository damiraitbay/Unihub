const Ticket = require('../models/Ticket');

// 🎟 Создать билет
exports.createTicket = async(req, res) => {
    try {
        const { userId, eventId, qrCode } = req.body;

        const ticket = await Ticket.create({ userId, eventId, qrCode });
        res.status(201).json(ticket);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при создании билета', error });
    }
};

// 📄 Получить все билеты
exports.getAllTickets = async(req, res) => {
    try {
        const tickets = await Ticket.find().populate('userId').populate('eventId');
        res.json(tickets);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при получении билетов', error });
    }
};

// 🔍 Получить билет по ID
exports.getTicketById = async(req, res) => {
    try {
        const ticket = await Ticket.findById(req.params.id).populate('userId').populate('eventId');
        if (!ticket) return res.status(404).json({ message: 'Билет не найден' });

        res.json(ticket);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при поиске билета', error });
    }
};

// ❌ Удалить билет
exports.deleteTicket = async(req, res) => {
    try {
        const ticket = await Ticket.findByIdAndDelete(req.params.id);
        if (!ticket) return res.status(404).json({ message: 'Билет не найден' });

        res.json({ message: 'Билет удалён' });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при удалении билета', error });
    }
};