const Recommendation = require('../models/Recommendation');

// 📥 Создать рекомендацию
exports.createRecommendation = async(req, res) => {
    try {
        const recommendation = await Recommendation.create(req.body);
        res.status(201).json({ message: 'Рекомендация создана', recommendation });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при создании рекомендации', error });
    }
};

// 📃 Получить все рекомендации
exports.getAllRecommendations = async(req, res) => {
    try {
        const recommendations = await Recommendation.find().populate('userId clubId');
        res.status(200).json(recommendations);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при получении рекомендаций', error });
    }
};

// 🔍 Получить рекомендацию по ID
exports.getRecommendationById = async(req, res) => {
    try {
        const recommendation = await Recommendation.findById(req.params.id).populate('userId clubId');
        if (!recommendation) return res.status(404).json({ message: 'Рекомендация не найдена' });
        res.status(200).json(recommendation);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при получении рекомендации', error });
    }
};

// ✏️ Обновить рекомендацию
exports.updateRecommendation = async(req, res) => {
    try {
        const updated = await Recommendation.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updated) return res.status(404).json({ message: 'Рекомендация не найдена' });
        res.status(200).json({ message: 'Рекомендация обновлена', updated });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при обновлении рекомендации', error });
    }
};

// ❌ Удалить рекомендацию
exports.deleteRecommendation = async(req, res) => {
    try {
        const deleted = await Recommendation.findByIdAndDelete(req.params.id);
        if (!deleted) return res.status(404).json({ message: 'Рекомендация не найдена' });
        res.status(200).json({ message: 'Рекомендация удалена' });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при удалении рекомендации', error });
    }
};