const User = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');

const pendingRegistrations = {}; // Временное хранилище email → { name, surname, hashedPassword, code }

const transporter = nodemailer.createTransport({
    service: 'gmail', // Используем Gmail
    auth: {
        user: process.env.EMAIL_USER, // Твой email на Gmail
        pass: process.env.EMAIL_PASS // Пароль приложения (созданный ранее)
    }
});

// 📩 Регистрация с отправкой кода
exports.register = async(req, res) => {
    const { name, surname, email, password, confirmPassword } = req.body;

    // Проверка на заполненность всех полей
    if (!name || !surname || !email || !password || !confirmPassword) {
        return res.status(400).json({ message: 'Пожалуйста, заполните все поля.' });
    }

    // Проверка формата email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return res.status(400).json({ message: 'Некорректный email формат.' });
    }

    // Проверка на корпоративный email
    if (!email.endsWith('@stu.sdu.edu.kz')) {
        return res.status(400).json({ message: 'Только корпоративная почта SDU разрешена.' });
    }

    // Проверка на уникальность email
    const existingUser = await User.findOne({ email });
    if (existingUser) {
        return res.status(400).json({ message: 'Пользователь с таким email уже зарегистрирован.' });
    }

    // Проверка длины пароля
    if (password.length < 6) {
        return res.status(400).json({ message: 'Пароль должен содержать минимум 6 символов.' });
    }

    // Проверка совпадения паролей
    if (password !== confirmPassword) {
        return res.status(400).json({ message: 'Пароли не совпадают.' });
    }

    // Генерация и сохранение кода
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const hashedPassword = await bcrypt.hash(password, 10);

    pendingRegistrations[email] = {
        name,
        surname,
        hashedPassword,
        code,
        createdAt: Date.now()
    };

    // Отправка кода на email
    try {
        await transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: email,
            subject: 'Код подтверждения регистрации',
            text: `Ваш код подтверждения: ${code}`
        });

        console.log(`[DEBUG] Код подтверждения для ${email}: ${code}`);
        res.status(200).json({ message: 'Код отправлен на вашу почту.' });
    } catch (error) {
        console.error('[EMAIL ERROR]', error);
        res.status(500).json({ message: 'Не удалось отправить код на почту.', error: error.message });
    }
};

// Подтверждение регистрации
exports.verify = async(req, res) => {
    const { email, code } = req.body;

    // Проверка на заполненность
    if (!email || !code) {
        return res.status(400).json({ message: 'Пожалуйста, укажите email и код.' });
    }

    const pending = pendingRegistrations[email];
    if (!pending) {
        return res.status(400).json({ message: 'Регистрация с этим email не найдена или уже подтверждена.' });
    }

    // Проверка срока действия (10 минут)
    const isExpired = (Date.now() - pending.createdAt) > 10 * 60 * 1000;
    if (isExpired) {
        delete pendingRegistrations[email];
        return res.status(400).json({ message: 'Срок действия кода истек. Пожалуйста, зарегистрируйтесь заново.' });
    }

    // Проверка кода
    if (pending.code !== code) {
        return res.status(400).json({ message: 'Неверный код подтверждения.' });
    }

    try {
        // Создание пользователя
        const user = await User.create({
            name: pending.name,
            surname: pending.surname,
            email,
            password: pending.hashedPassword,
            role: 'Student'
        });

        delete pendingRegistrations[email];

        // Генерация токена
        const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
            expiresIn: '7d'
        });

        res.status(201).json({ message: 'Регистрация успешна!', token, user });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при создании аккаунта.', error: error.message });
    }
};

// Логин пользователя
exports.loginUser = async(req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'Пользователь не найден.' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Неверный пароль.' });
        }

        // Генерация JWT
        const token = jwt.sign({ id: user._id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.status(200).json({ token, user: { email: user.email, username: user.username } });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при авторизации пользователя.', error: error.message });
    }
};

// Запрос на сброс пароля
exports.forgotPassword = async(req, res) => {
    const { email } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'Пользователь с таким email не найден.' });
        }

        // Генерация токена сброса пароля
        const resetToken = Math.random().toString(36).substring(2, 15);
        user.resetToken = resetToken;
        await user.save();

        // Ссылка для сброса пароля
        const resetLink = `http://localhost:3000/reset-password/${resetToken}`;

        const mailOptions = {
            from: process.env.EMAIL_USER,
            to: email,
            subject: 'Инструкция для сброса пароля',
            text: `Вы запросили сброс пароля. Для продолжения, перейдите по следующей ссылке: ${resetLink}`
        };

        await transporter.sendMail(mailOptions);
        res.json({ message: 'Инструкция для сброса пароля отправлена на вашу почту.' });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при отправке инструкции.', error: error.message });
    }
};

// Сброс пароля
exports.resetPassword = async(req, res) => {
    const { token, newPassword } = req.body;

    try {
        const user = await User.findOne({ resetToken: token });
        if (!user) {
            return res.status(400).json({ message: 'Неверный токен для сброса пароля.' });
        }

        const hashedPassword = await bcrypt.hash(newPassword, 10);
        user.password = hashedPassword;
        user.resetToken = undefined;
        await user.save();

        res.json({ message: 'Пароль успешно изменен.' });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при сбросе пароля.', error: error.message });
    }
};