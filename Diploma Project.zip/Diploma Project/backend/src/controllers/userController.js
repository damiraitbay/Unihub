const User = require('../models/User'); // Импорт модели пользователя
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Регистрация пользователя
exports.registerUser = async(req, res) => {
    const { username, email, password } = req.body;

    try {
        // Проверка на наличие пользователя с таким email
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'Пользователь с таким email уже существует.' });
        }

        // Хеширование пароля
        const hashedPassword = await bcrypt.hash(password, 10);

        // Создание нового пользователя
        const newUser = new User({
            username,
            email,
            password: hashedPassword,
        });

        // Сохранение нового пользователя в базе
        await newUser.save();
        res.status(201).json({ message: 'Пользователь успешно зарегистрирован.' });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при регистрации пользователя.', error: error.message });
    }
};

// Логин пользователя
exports.loginUser = async(req, res) => {
    const { email, password } = req.body;

    try {
        // Поиск пользователя по email
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'Пользователь не найден.' });
        }

        // Сравнение введенного пароля с сохраненным в базе
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Неверный пароль.' });
        }

        // Создание JWT токена
        const token = jwt.sign({ id: user._id, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });

        res.status(200).json({ token });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при авторизации пользователя.', error: error.message });
    }
};

// Получить информацию о пользователе
exports.getUserInfo = async(req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ message: 'Пользователь не найден.' });
        }

        // Скрываем пароль перед отправкой данных о пользователе
        const { password, ...userData } = user._doc;
        res.status(200).json(userData);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при получении информации о пользователе.', error: error.message });
    }
};

// Обновить информацию о пользователе
exports.updateUserInfo = async(req, res) => {
    const { username, email, password } = req.body;

    try {
        const user = await User.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ message: 'Пользователь не найден.' });
        }

        // Обновление данных пользователя
        if (username) user.username = username;
        if (email) user.email = email;
        if (password) user.password = await bcrypt.hash(password, 10);

        await user.save();
        res.status(200).json({ message: 'Информация о пользователе обновлена.' });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при обновлении информации о пользователе.', error: error.message });
    }
};

// Удалить пользователя
exports.deleteUser = async(req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ message: 'Пользователь не найден.' });
        }

        await user.remove();
        res.status(200).json({ message: 'Пользователь удален.' });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка при удалении пользователя.', error: error.message });
    }
};