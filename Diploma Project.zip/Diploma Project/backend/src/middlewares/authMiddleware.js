const jwt = require('jsonwebtoken');

// ✅ Middleware: проверка токена и добавление пользователя в req
const authenticateUser = (req, res, next) => {
    const token = req.header('Authorization');

    if (!token) {
        return res.status(401).json({ message: 'Нет авторизации' });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        return res.status(401).json({ message: 'Неверный токен' });
    }
};

// ✅ Middleware: проверка, что пользователь — админ
const isAdmin = (req, res, next) => {
    if (req.user && req.user.role === 'Admin') {
        return next();
    }
    return res.status(403).json({ message: 'Доступ только для админов' });
};

module.exports = {
    authenticateUser,
    isAdmin,
    verifyToken: authenticateUser
};